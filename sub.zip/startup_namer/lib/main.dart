import 'package:flutter/gestures.dart';
import 'package:provider/provider.dart';
import 'package:english_words/english_words.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';






void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(App());
}
enum Status { Uninitialized, Authenticated, Authenticating, Unauthenticated, }






 class AuthRepository with ChangeNotifier {

  FirebaseAuth _auth;
  User? _user;
  Status _status = Status.Uninitialized;
  FirebaseFirestore _firestore = FirebaseFirestore.instance;
  Set<WordPair> favourites = new Set<WordPair>();

  AuthRepository.instance() : _auth = FirebaseAuth.instance {
    _auth.authStateChanges().listen(_onAuthStateChanged);
    _user = _auth.currentUser;
    _onAuthStateChanged(_user);
  }

  Status get status => _status;

  User? get user => _user;

  bool get isAuthenticated => status == Status.Authenticated;

  Future<UserCredential?> signUp(String email, String password) async {
    try {
      _status = Status.Authenticating;
      notifyListeners();
      return await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
    } catch (e) {
      // print(e);
      _status = Status.Unauthenticated;
      notifyListeners();
      return null;
    }
  }

  Future<bool> signIn(String email, String password) async {
    try {
      _status = Status.Authenticating;
      notifyListeners();
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      favourites = await getfavourites();
      notifyListeners();
      return true;
    } catch (e) {
      _status = Status.Unauthenticated;
      notifyListeners();
      return false;
    }
  }

  Future<bool> createUserWithEmailAndPassword(String email, String password) async {
    try {
      _status = Status.Authenticating;
      notifyListeners();
      await _auth.createUserWithEmailAndPassword(email: email, password: password);
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      favourites = await getfavourites();
      notifyListeners();
      return true;
    } catch (e) {
      _status = Status.Unauthenticated;
      notifyListeners();
      return false;
    }
  }
  Future signOut() async {
    // FirebaseAuth.instance.signOut();
    _auth.signOut();
    _status = Status.Unauthenticated;
    notifyListeners();
    return Future.delayed(Duration.zero);
  }


  Future<void> _onAuthStateChanged(User? firebaseUser) async {
    if (firebaseUser == null) {
      _user = null;
      _status = Status.Unauthenticated;
    } else {
      _user = firebaseUser;
      _status = Status.Authenticated;
      favourites = await getfavourites();
    }
    notifyListeners();
  }

  Future<Set<WordPair>> getfavourites() async {
    Set<WordPair> s = new Set<WordPair>();
    await _firestore
        .collection("users")
        .doc(_user!.uid)
        .collection('favourites')
        .get()
        .then((querySnapshot) {
      querySnapshot.docs.forEach((result) {
        String first = result.data().entries.first.value.toString();
        String second = result.data().entries.last.value.toString();
        s.add(WordPair(first, second));
      });
    });
    return Future<Set<WordPair>>.value(s);
  }

  Set<WordPair> getuploadedfavourites() {
    return favourites;
  }

  void addPair(WordPair pair) async {
    if (_status == Status.Authenticated) {
      await _firestore
          .collection("users")
          .doc(_user!.uid)
          .collection("favourites")
          .doc(pair.toString())
          .set({
        'first': pair.first.toString(),
        'second': pair.second.toString()
      });
    }
    favourites = await getfavourites();
    notifyListeners();
  }

  void removePair(WordPair pair) async {
    if (_status == Status.Authenticated) {
      await _firestore
          .collection("users")
          .doc(_user!.uid)
          .collection('favourites')
          .doc(pair.toString())
          .delete();
      favourites = await getfavourites();
      notifyListeners();
    }
  }
}

class App extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
              body: Center(
                  child: Text(snapshot.error.toString(),
                      textDirection: TextDirection.ltr)));
        }
        if (snapshot.connectionState == ConnectionState.done) {
          return MyApp();
        }
        return Center(child: CircularProgressIndicator());
      },
    );
  }
}


class MyApp extends StatelessWidget {
  // const MyApp({super.key});


    @override
    Widget build(BuildContext context) {
      return ChangeNotifierProvider(
        create: (_) => AuthRepository.instance(),
        child: Consumer<AuthRepository>(
          builder: (context, login, _) =>
              MaterialApp(
                theme: ThemeData(
                    appBarTheme: const AppBarTheme(color: Colors.deepPurple)),
                title: 'Startup Name Generator',
                initialRoute: '/',
                routes: {
                  '/': (context) => RandomWords(),
                  '/login': (context) => LoginScreen(),
                  '/register': (context) => LoginScreen(),
                },
              ),
        ) ,
      );
    }

}


class RandomWords extends StatefulWidget {
  // const RandomWords({super.key});

  @override
  State<RandomWords> createState() => _RandomWordsState();

}

class _RandomWordsState extends State<RandomWords> {


  final _suggestions = <WordPair>[];
  final _saved = <WordPair>{};
  final _biggerFont = const TextStyle(fontSize: 18);
  var user;


  Widget _buildSuggestions() {
    return ListView.builder(
        padding: const EdgeInsets.all(16),

        itemBuilder: (BuildContext _context, int i) {

          if (i.isOdd) {
            return Divider();
          }

          final int index = i ~/ 2;

          if (index >= _suggestions.length) {

            _suggestions.addAll(generateWordPairs().take(10));
          }

          return _buildRow(_suggestions[index]);
        });
  }

  Widget _buildRow(WordPair pair) {
    final alreadySaved = _saved.contains(pair) ||
        (user.getuploadedfavourites().contains(pair) &&
            user._status == Status.Authenticated);
    final uploaded = user.getuploadedfavourites().contains(pair) &&
        user._status == Status.Authenticated;

    final savedlocaly = _saved.contains(pair);
    if (!uploaded && savedlocaly) {
      user.addPair(pair);
    }

    return ListTile(
      title: Text(
        pair.asPascalCase,
        style: _biggerFont,
      ),
      trailing: Icon(
        alreadySaved ? Icons.star : Icons.star_border,
        color: alreadySaved ? Colors.deepPurple : null,
        semanticLabel: alreadySaved ? 'Remove from saved' : 'Save',
      ),
      onTap: () {
        setState(() {
          if (alreadySaved) {
            _saved.remove(pair);
            user.removePair(pair);
          } else {
            _saved.add(pair);
            user.addPair(pair);
          }
        });
      },
    );
  }

  void _pushSaved() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) {
          final user = Provider.of<AuthRepository>(context);

          var favourites = _saved;
          if (user._status == Status.Authenticated) {
            favourites = user.getuploadedfavourites();
          } else {
            favourites = _saved;
          }

          final tiles = favourites.map(
                (pair) {
              return Dismissible(
                key: ValueKey<int>(pair.hashCode),
                child: ListTile(
                  title: Text(
                    pair.asPascalCase,
                    style: _biggerFont,
                  ),
                ),
                background: Container(
                  color: Colors.deepPurple,
                  child: Row(
                    children: [
                      Icon(
                        Icons.delete,
                        color: Colors.white,
                      ),
                      Text(
                        'Delete Suggestion',
                        style: TextStyle(color: Colors.white),
                      )
                    ],
                  ),
                ),
                onDismissed: (DismissDirection) async {
                  user.removePair(pair);
                  _saved.remove(pair);
                  setState(() {});
                },
                confirmDismiss: (DismissDirection direction) async {
                  final deletion = pair.asPascalCase;

                  return await showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: const Text("Delete Suggestion"),
                        content: Text(
                            "are you sure you want to delete ${deletion} from your saved suggestions?"),
                        actions: <Widget>[
                          ElevatedButton(
                              onPressed: () => Navigator.of(context).pop(true),
                              child: const Text(
                                "Yes",
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                primary: Colors.deepPurple,
                              )),
                          ElevatedButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              child: const Text(
                                "No",
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                primary: Colors.deepPurple,
                              )),
                        ],
                      );
                    },
                  );
                },
              );
            },
          );
          final divided = tiles.isNotEmpty
              ? ListTile.divideTiles(
            context: context,
            tiles: tiles,
          ).toList()
              : <Widget>[];

          return Scaffold(
            appBar: AppBar(
              title: const Text('Saved Suggestions'),
            ),
            body: ListView(children: divided),
          );
        },
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
    user = Provider.of<AuthRepository>(context);

    var icon_to_view = Icons.login;
    var function_on_press = _login;
    if (user._status == Status.Authenticated) {
      icon_to_view = Icons.exit_to_app;
      function_on_press = _logout;
    }
    return Scaffold(
      appBar: AppBar(
        title: Text('Startup Name Generator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.star),
            onPressed: _pushSaved,
            tooltip: 'Saved Suggestions',
          ),
          IconButton(
            icon: Icon(icon_to_view),
            onPressed: function_on_press,
          )
        ],
      ),
      body: _buildSuggestions(),
    );
  }


  void _login() {
    _saved.clear();
    Navigator.of(context).pushNamed('/login');
  }



  void _logout() async {
     // FirebaseAuth.instance.signOut();
     await user.signOut();
     // FirebaseAuth = Status.Unauthenticated;
     final snackbar = SnackBar(
      content: Text('Successfully logged out'),
      backgroundColor: Colors.deepPurple,
    );
    ScaffoldMessenger.of(context).showSnackBar(snackbar);
    _saved.clear();
    setState(() {});
  }


  // void _pushLogin() {
  //   Navigator.of(context).push(
  //       MaterialPageRoute<void>(
  //           builder: (context) {
  //             final email = Container(
  //               child: TextFormField(
  //                 decoration: const InputDecoration(
  //                   contentPadding: EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
  //                   hintText: 'Email',
  //                   hintStyle: TextStyle(color: Colors.grey),
  //                 ),
  //               ),
  //               margin: const EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
  //             );
  //             final password = Container(
  //               child: TextFormField(
  //                 decoration: const InputDecoration(
  //                     contentPadding: EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
  //                     hintText: 'Password',
  //                     hintStyle: TextStyle(color: Colors.grey)
  //                 ),
  //               ),
  //               margin: const EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
  //             );
  //             final loginButton = Container(
  //               child: ElevatedButton(
  //                 onPressed: () {
  //                   const snackBar = SnackBar(content: Text('Login is not implemented yet'));
  //                   ScaffoldMessenger.of(context).showSnackBar(snackBar);
  //                 },
  //                 child: const Text('Log in'),
  //                 style: ElevatedButton.styleFrom(
  //                   primary: Colors.deepPurple,
  //                   padding: const EdgeInsets.symmetric(horizontal: 16),
  //                   shape: const RoundedRectangleBorder(
  //                     borderRadius: BorderRadius.all(Radius.circular(100)),
  //                   ),
  //                 ),
  //               ),
  //               margin: const EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
  //             );
  //             final welcomeText = Container(
  //               child: const Text('welcome to Startup Names Generator, please log in below', style: TextStyle(fontSize: 18)),
  //               margin: const EdgeInsets.only(left: 15, bottom: 25, top: 15, right: 15),
  //             );
  //             return Scaffold(
  //               appBar: AppBar(
  //                 title: const Text('Login'),
  //               ),
  //               body: ListView(children: [welcomeText, email, password, loginButton],),
  //             );
  //           }
  //       )
  //   );
  // }




  // @override
  // Widget build(BuildContext context) {
  //   return Scaffold(
  //     appBar: AppBar(
  //       title: const Text('Startup Name Generator'),
  //       actions: [
  //         IconButton(
  //           icon: const Icon(Icons.star),
  //           onPressed: _pushSaved,
  //           tooltip: 'Saved Suggestions',
  //         ),
  //         IconButton(onPressed: _pushLogin, icon: const Icon(Icons.login)),
  //       ],
  //     ),
  //     body: ListView.builder(
  //       padding: const EdgeInsets.all(16.0),
  //       itemBuilder: (context, i) {
  //         if (i.isOdd) return const Divider();
  //
  //         final index = i ~/ 2;
  //         if (index >= _suggestions.length) {
  //           _suggestions.addAll(generateWordPairs().take(10));
  //         }
  //         final alreadySaved = _saved.contains(_suggestions[index]); // NEW
  //
  //         return ListTile(
  //           title: Text(
  //             _suggestions[index].asPascalCase,
  //             style: _biggerFont,
  //           ),
  //           trailing: Icon(    // NEW from here ...
  //             alreadySaved ? Icons.star : Icons.star_border,
  //             color: alreadySaved ? Colors.deepPurple : null,
  //             semanticLabel: alreadySaved ? 'Remove from saved' : 'Save',
  //           ),
  //           onTap: () {          // NEW from here ...
  //             setState(() {
  //               if (alreadySaved) {
  //                 _saved.remove(_suggestions[index]);
  //               } else {
  //                 _saved.add(_suggestions[index]);
  //               }
  //             });                // to here.
  //           },
  //         );
  //       },
  //     ),
  //   );
  // }
}

class LoginScreen extends StatefulWidget {
  // final VoidCallback onClickedSignUp;
  @override
  _LoginScreen createState() => _LoginScreen();
}

// class Register extends StatefulWidget {
//   const Register({Key? key}) : super(key: key);
//
//   @override
//   State<Register> createState() => _RegisterState();
// }
//
// class _RegisterState extends State<Register> {
//   @override
//   Widget build(BuildContext context) {
//     return Container();
//   }
// }


class _LoginScreen extends State<LoginScreen> {
  var scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<AuthRepository>(context);
    TextEditingController emailcontroller = new TextEditingController();
    TextEditingController passwordcontroller = new TextEditingController();
    return Scaffold(
        key: scaffoldKey,
        appBar: AppBar(
          title: const Text('Login'),
        ),
        body: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(25)),
            Text(
              'Welcome to Startup Names Generator, please log in or sign up below',
              style: TextStyle(fontSize: 17),
            ),
            const Padding(padding: EdgeInsets.all(10)),
            TextField(

              controller: emailcontroller,
              decoration: const InputDecoration(
                  labelText: 'Email', labelStyle: TextStyle(fontSize: 20),
                // errorText: _validate ? 'Value Can\'t Be Empty' : null,
              ),
            ),
            const Padding(padding: EdgeInsets.all(10)),
            TextField(
              controller: passwordcontroller,
              obscureText: true,
              enableSuggestions: false,
              autocorrect: false,
              decoration: const InputDecoration(
                  labelText: 'Password', labelStyle: TextStyle(fontSize: 20)),
            ),
            const Padding(padding: EdgeInsets.all(10)),
            user.status == Status.Authenticating
                ? Center(
                child: CircularProgressIndicator(
                  color: Colors.deepPurple,
                  backgroundColor: Colors.white,
                )) :
                 Column(
                  children: [
                    ElevatedButton(
              onPressed: () async {
                    bool res = await user.signIn(
                        emailcontroller.text, passwordcontroller.text);

                    if (res == false) {
                      final snackbar = SnackBar(
                        content:
                        Text('There was an error logging into the app'),
                        backgroundColor: Colors.deepPurple,
                      );
                      ScaffoldMessenger.of(context).showSnackBar(snackbar);
                    } else {
                      // FirebaseAuth.instance.currentUser
                      // user.status= Status.Authenticated;
                      Navigator.pop(context);
                    }
              },
              child: const Text(
                    'Log in',
                    style: TextStyle(color: Colors.white),
              ),
              style: ElevatedButton.styleFrom(
                    primary: Colors.deepPurple,
                    onPrimary: Colors.white,
                    shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(30.0),
                    ),
                    fixedSize: const Size(290, 40),
              ),
            ),
                    // RichText(
                    //   text: TextSpan(
                    //     style: TextStyle(color: Colors.black, fontSize: 20),
                    //     text: 'No account? ',
                    //     children: [
                    //       TextSpan(
                    //           recognizer: TapGestureRecognizer()
                    //             ..onTap()=widget.onClickedSignUp,
                    //         text: 'Sign up',
                    //         style: TextStyle(
                    //           decoration: TextDecoration.underline,
                    //           color: Colors.deepPurple
                    //         )
                    //       )
                    //     ]
                    //   ),
                    // ),

                    ElevatedButton(
                      onPressed: () async {
                        bool res;
                        if(emailcontroller.text.isNotEmpty && passwordcontroller.text.isNotEmpty)
                          {
                            res = await user.createUserWithEmailAndPassword(
                                emailcontroller.text, passwordcontroller.text) ;
                            // res = true;
                            // res = await user.signIn(
                            //     emailcontroller.text, passwordcontroller.text);
                          }
                        else { res = false; }
                        // AuthResult res= await user.crea



                        if (res == false) {
                          final snackbar = SnackBar(
                            content:
                            Text('There was an error signing up into the app'),
                            backgroundColor: Colors.deepPurple,
                          );
                          ScaffoldMessenger.of(context).showSnackBar(snackbar);
                        } else {
                          Navigator.pop(context);

                          // final snackbar = SnackBar(
                          //   content:
                          //   Text('Log in using your new account!'),
                          //   backgroundColor: Colors.deepPurple,
                          // );
                          // ScaffoldMessenger.of(context).showSnackBar(snackbar);
                        }
                      },
                      child: const Text(
                        'Sign up',
                        style: TextStyle(color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.deepPurple,
                        onPrimary: Colors.white,
                        shape: new RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(30.0),
                        ),
                        fixedSize: const Size(290, 40),
                      ),
                    ),
                  ],
                ),
          ],
        ));
  }
}




// void _pushSaved() {
//   Navigator.of(context).push(
//     MaterialPageRoute<void>(
//       builder: (context) {
//         final tiles = _saved.map(
//               (pair) {
//             return ListTile(
//               title: Text(
//                 pair.asPascalCase,
//                 style: _biggerFont,
//               ),
//             );
//           },
//         ).toList();
//         // return Scaffold()
//         final divided = tiles.isNotEmpty
//             ? ListTile.divideTiles(
//           context: context,
//           tiles: tiles,
//         ).toList()
//             : <Widget>[];
//
//         return Scaffold(
//           appBar: AppBar(
//             title: const Text('Saved Suggestions'),
//           ),
//           body: ListView(children: divided),
//         );
//       },
//     ), // ...to here.
//   );
// }
