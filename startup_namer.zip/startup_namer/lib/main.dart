import 'package:english_words/english_words.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      title: 'Startup Name Generator',
      theme: ThemeData(          // Add the 5 lines from here...
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.white,
        ),
      ),
      home: const RandomWords(),
    );
  }
}




class RandomWords extends StatefulWidget {
  const RandomWords({super.key});

  @override
  State<RandomWords> createState() => _RandomWordsState();

}

class _RandomWordsState extends State<RandomWords> {


  final _suggestions = <WordPair>[];
  final _saved = <WordPair>{};
  final _biggerFont = const TextStyle(fontSize: 18);

  void _pushSaved() {
    Navigator.of(context).push(
        MaterialPageRoute<void>(
            builder: (context) {
              final tiles = _saved.map(
                      (pair) {
                    return ListTile(
                        title: Text(
                          pair.asPascalCase,
                          style: _biggerFont,
                        )
                    );
                  }
              ).toList();
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Saved Suggestions'),
                ),
                body: ListView.separated(
                  itemCount: tiles.length,
                  separatorBuilder: (context, index) => const Divider(),
                  itemBuilder: (context, index) {
                    return Dismissible(
                      key: ValueKey<int>(index),
                      child: tiles[index],
                      onDismissed: (dir) {},
                      confirmDismiss: (dir) {
                        const snackBar = SnackBar(content: Text('Deletion is not implemented yet'));
                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                        return Future.value(false);
                      },
                      background: Container(
                        child: Row(children: const [Icon(Icons.delete, color: Colors.white,), Text('Delete Suggestion', style: TextStyle(color: Colors.white, fontSize: 15),)],),
                        color: Colors.deepPurple,
                      ),
                    );
                  },
                ),
              );
            }
        )
    );
  }

  // void _pushSaved() {
  //   Navigator.of(context).push(
  //     MaterialPageRoute<void>(
  //       builder: (context) {
  //         final tiles = _saved.map(
  //               (pair) {
  //             return ListTile(
  //               title: Text(
  //                 pair.asPascalCase,
  //                 style: _biggerFont,
  //               ),
  //             );
  //           },
  //         ).toList();
  //         // return Scaffold()
  //         final divided = tiles.isNotEmpty
  //             ? ListTile.divideTiles(
  //           context: context,
  //           tiles: tiles,
  //         ).toList()
  //             : <Widget>[];
  //
  //         return Scaffold(
  //           appBar: AppBar(
  //             title: const Text('Saved Suggestions'),
  //           ),
  //           body: ListView(children: divided),
  //         );
  //       },
  //     ), // ...to here.
  //   );
  // }

  void _pushLogin() {
    Navigator.of(context).push(
        MaterialPageRoute<void>(
            builder: (context) {
              final email = Container(
                child: TextFormField(
                  decoration: const InputDecoration(
                    contentPadding: EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
                    hintText: 'Email',
                    hintStyle: TextStyle(color: Colors.grey),
                  ),
                ),
                margin: const EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
              );
              final password = Container(
                child: TextFormField(
                  decoration: const InputDecoration(
                      contentPadding: EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
                      hintText: 'Password',
                      hintStyle: TextStyle(color: Colors.grey)
                  ),
                ),
                margin: const EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
              );
              final loginButton = Container(
                child: ElevatedButton(
                  onPressed: () {
                    const snackBar = SnackBar(content: Text('Login is not implemented yet'));
                    ScaffoldMessenger.of(context).showSnackBar(snackBar);
                  },
                  child: const Text('Log in'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.deepPurple,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(100)),
                    ),
                  ),
                ),
                margin: const EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
              );
              final welcomeText = Container(
                child: const Text('welcome to Startup Names Generator, please log in below', style: TextStyle(fontSize: 18)),
                margin: const EdgeInsets.only(left: 15, bottom: 25, top: 15, right: 15),
              );
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Login'),
                ),
                body: ListView(children: [welcomeText, email, password, loginButton],),
              );
            }
        )
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Startup Name Generator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.star),
            onPressed: _pushSaved,
            tooltip: 'Saved Suggestions',
          ),
          IconButton(onPressed: _pushLogin, icon: const Icon(Icons.login)),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemBuilder: (context, i) {
          if (i.isOdd) return const Divider();

          final index = i ~/ 2;
          if (index >= _suggestions.length) {
            _suggestions.addAll(generateWordPairs().take(10));
          }
          final alreadySaved = _saved.contains(_suggestions[index]); // NEW

          return ListTile(
            title: Text(
              _suggestions[index].asPascalCase,
              style: _biggerFont,
            ),
            trailing: Icon(    // NEW from here ...
              alreadySaved ? Icons.star : Icons.star_border,
              color: alreadySaved ? Colors.deepPurple : null,
              semanticLabel: alreadySaved ? 'Remove from saved' : 'Save',
            ),
            onTap: () {          // NEW from here ...
              setState(() {
                if (alreadySaved) {
                  _saved.remove(_suggestions[index]);
                } else {
                  _saved.add(_suggestions[index]);
                }
              });                // to here.
            },
          );
        },
      ),
    );
  }
}

